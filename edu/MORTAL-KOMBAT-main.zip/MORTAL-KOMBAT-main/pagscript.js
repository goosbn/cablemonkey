function audio(element)
{
    var audio1 = new Audio();
    audio1.src = "./audios/MortalKombat1.mp3";
    audio1.play()
}
 function Pose(){
    var song = new Audio();
    song.src =  "./audios/sound_chosen.mp3"
    song.play()
 } 